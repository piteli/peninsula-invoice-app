export const INVOICE_ID = '#RT3080';
export const INVOICE_DATE = '19 Aug 2021';
export const INVOICE_PERSON_TO = 'Jensen Huang';
export const INVOICE_MONEY = '€1,800.90';
export const INVOICE_STATUS = "Paid";