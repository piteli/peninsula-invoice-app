export const INPUT_LABEL = 'Issue Date';

export const monthsThreeLetter = [
    'Jan',
    'Feb',
    'Mac',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec' 
];