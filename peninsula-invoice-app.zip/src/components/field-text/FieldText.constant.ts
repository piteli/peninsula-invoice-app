export const PLACEHOLDER = "";
export const INPUT_LABEL = "Street Address";