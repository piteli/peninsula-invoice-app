export const AUTHENTICATION_TYPE = {
    NONE: 'none',
    BASIC: 'Basic',
    BEARER: 'Bearer'
}