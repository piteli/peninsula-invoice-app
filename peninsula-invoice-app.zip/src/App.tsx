import MainView from './views/Main';

function App() {
  return (
    <MainView />
  );
}

export default App;
