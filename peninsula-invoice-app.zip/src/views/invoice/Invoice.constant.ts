export const INVOICE_HEADING_LABEL = "Invoices";
export const EMPTY_LABEL_ONE = 'There is nothing here';