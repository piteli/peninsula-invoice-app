import React from 'react';
import SideBarHomeComponent from '../components/side-bar-home/SideBarHome.component';
import InvoiceView from './invoice/Invoice';
import './Main.css';
import SideBarInvoiceComponent from '../components/side-bar-invoice/SideBarInvoice.component';
import ModalAddItemComponent from '../components/modal-add-item/ModalAddItem.component';
import { ItemListDataSourceModel, CreateInvoiceInputsModel } from '../components/side-bar-invoice/SideBarInvoice.model';
import ModalViewInvoiceComponent from '../components/modal-view-invoice/ModalViewInvoice.component';
import ApiService from '../services/Api.service';
import { AUTHENTICATION_TYPE } from '../utils/constants/http.constant';

function MainView() {
    const [isDarkTheme, setDarkTheme] = React.useState<boolean>(true);
    const [isInvoiceMenuOpen, setInvoiceMenuOpen] = React.useState<boolean>(false);
    const [isAddItemModalOpen, setAddItemModalOpen] = React.useState<boolean>(false);
    const [isInvoiceViewModalOpen, setInvoiceViewModalOpen] = React.useState<boolean>(false);
    const [dataSourceInvoices, setDataSourceInvoices] = React.useState<CreateInvoiceInputsModel[]>([]);
    const [addItemsData, setAddItemsData] = React.useState<ItemListDataSourceModel[]>([]);
    const [invoiceDetailView, setInvoiceDetailView] = React.useState<CreateInvoiceInputsModel>();

    React.useEffect(() => {
        loadInvoiceDataFromAPI();
    }, []);
    
    React.useEffect(() => {
        if(invoiceDetailView !== undefined) {
            setInvoiceViewModalOpen(true);
        }
    }, [invoiceDetailView]);

    function retrieveInputsFromModal(value: ItemListDataSourceModel) {
        let addItems = addItemsData;
        addItems.push(value);
        setAddItemsData(addItems);
    }

    function saveCreatedInvoiceToMainView(payload: CreateInvoiceInputsModel) {
        setDataSourceInvoices([...dataSourceInvoices, payload]);
    }
    
    async function loadInvoiceDataFromAPI() {
        try {
            const response = await new ApiService().get('./data.json', AUTHENTICATION_TYPE.NONE);
            const json = await response.json();
        } catch(e) {
            console.log(e);
        }
    }

    return(
        <div className='top-main-container'>
            <SideBarHomeComponent setDarkTheme={setDarkTheme} isDarkTheme={isDarkTheme} />
            { isInvoiceMenuOpen || isInvoiceViewModalOpen ? <div className='backdrop'></div> : null }
            {
                isInvoiceMenuOpen ?
                    <div className='side-bar-overlay'>
                        <SideBarInvoiceComponent 
                            addItemsData={addItemsData} 
                            setInvoiceMenuOpen={setInvoiceMenuOpen} 
                            setAddItemModalOpen={setAddItemModalOpen}
                            saveCreatedInvoiceToMainView={saveCreatedInvoiceToMainView} 
                        />
                    </div>
                    :
                    null
            }
            {
                isInvoiceViewModalOpen ?
                    <div>
                        <ModalViewInvoiceComponent />
                    </div>
                    :
                    null
            }
            {
                isAddItemModalOpen ?
                <ModalAddItemComponent 
                    setAddItemModalOpen={setAddItemModalOpen} 
                    retrieveInputs={retrieveInputsFromModal} 
                /> : null
            }
            <div className='content'>
                <InvoiceView 
                    dataSourceInvoices={dataSourceInvoices} 
                    isInvoiceMenuOpen={isInvoiceMenuOpen} 
                    setInvoiceMenuOpen={setInvoiceMenuOpen} 
                    setInvoiceDetailView={setInvoiceDetailView}
                />
            </div>
        </div>
    );
}

export default MainView;