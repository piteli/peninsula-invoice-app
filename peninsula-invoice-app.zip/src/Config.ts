export const isDarkTheme = true;
export const BASE_URL = 'base-url-here';